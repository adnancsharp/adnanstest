﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using Satsuma.Specflow.Selenium.Tests.Specflow_Content;
using TechTalk.SpecFlow;

namespace Satsuma.Specflow.Selenium.Tests.Steps
{
    [Binding]
    public class LoginSteps
    {
		IWebDriver driver;
		private readonly Context context;

		public LoginSteps(Context context)
		{
			this.context = context;
		}

			[SetUp]
        [Given(@"the correct URL loads")]
        public void GivenTheCorrectURLLoads()
        {
			driver = new FirefoxDriver(); //using chrome
			driver.Navigate().GoToUrl(@"https://automationtestwebsite.azurewebsites.net/"); //url
			driver.Manage().Window.Maximize(); //maximise window
			IJavaScriptExecutor jse = (IJavaScriptExecutor)driver; //this java script is used to prevent not found element selenium error
			jse.ExecuteScript("window.scrollBy(110,350)", "");
		}

		[Given(@"I have entered the '(.*)' and '(.*)'")]
		public void GivenIHaveEnteredTheAnd(string username, string password)
		{
			context.Username = username;
			context.Password = password;

			IWebElement usernameTextbox = driver.FindElement(By.XPath("//input[@id='Email']"));
			usernameTextbox.SendKeys(username);
			IWebElement passwordTextbox = driver.FindElement(By.XPath("//input[@id='Password']"));
			passwordTextbox.SendKeys(password);
			}

		[When(@"I have clicked the login button")]
		public void WhenIHaveClickedTheLoginButton()
		{
			IWebElement loginButton = driver.FindElement(By.XPath("//input[@id='loginbtn']"));
			loginButton.Click();
		}

		[Then(@"the user is sucesfully logged in")]
		public void ThenTheUserIsSucesfullyLoggedIn()
		{
			string loggedInSuccess = "/Home/Login";
			string currentURL = new Uri(driver.Url).AbsolutePath;

			if (loggedInSuccess != currentURL)
			{
				throw new Exception("Error has occured when trying to login. The login has not navigated to the correct URL");
			}

			Assert.IsTrue(currentURL.Equals(loggedInSuccess));

			string expectedLoginSuccessMessage = "Welcome " +context.Username;
			string loginMessageDisplayed = null;

			try
			{
				IWebElement loginMessage = driver.FindElement(By.XPath("//h2[contains(text(),'Successfully logged in.')]"));
				loginMessageDisplayed = loginMessage.Text;
			}
			catch(Exception e)
			{
				throw new Exception("Login failed! Check login details!", e);
			}

			if (loginMessageDisplayed == expectedLoginSuccessMessage)
			{
				Console.WriteLine("User Succesfully logged in. Correct login message displayed");
				Assert.IsTrue(loginMessageDisplayed.Equals(expectedLoginSuccessMessage));
			}
			else
			{
				Console.WriteLine("User Succesfully logged in. Incorrect login message displayed");
				throw new Exception("User Succesfully logged in. Incorrect login message displayed. Expected login message -> " + expectedLoginSuccessMessage);
			}
		}

		[Then(@"the correct '(.*)' displays")]
		public void ThenTheCorrectDisplays(string expectedMessage)
		{
			string usermessageResult = string.Empty;
			IWebElement usermessage = driver.FindElement(By.XPath("//span[@class='field-validation-error']"));
			usermessageResult = usermessage.Text;
			Console.WriteLine(usermessageResult + " message has been found the webpage");

				if (context.Username == "" && context.Password != "") //password only
				{
				Console.WriteLine("Checking display message only when password entered");
				Assert.AreEqual(expectedMessage,usermessageResult,string.Format("'"+expectedMessage+"'" + " was the message expected to be displayed " + usermessageResult + " is the incorrect message"));
				}

				if (context.Username != "" && context.Password == "") //username only
				{
				Console.WriteLine("Checking display message only when username entered");
				Assert.AreEqual(expectedMessage, usermessageResult, string.Format("'" + expectedMessage + "'" + " was the message expected to be displayed " + usermessageResult + " is the incorrect message"));
			}

			if (context.Username != "" && context.Password != "") //wrong username and password
				{
				Console.WriteLine("Checking display message when wrong user and password entered");
				Assert.AreEqual(expectedMessage, usermessageResult, string.Format("'" + expectedMessage + "'" + " was the message expected to be displayed " + usermessageResult + " is the incorrect message"));
			}
		}

		[AfterScenario("login")]
		public void AfterScenario()
		{
			driver.Quit();
		}
	}
}
