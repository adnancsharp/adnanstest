﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Satsuma.Specflow.Selenium.Tests.Specflow_Content
{
	public class Context
	{
		private string username = string.Empty;
		private string password = string.Empty;

		public string Username
		{
			get
			{
				return username;
			}
			set
			{
				Console.WriteLine("Username" + value + " added to context");
				username = value;
			}
		}

		public string Password
		{
			get
			{
				return password;
			}
			set
			{
				Console.WriteLine("Password" + value + " added to context");
				password = value;
			}
		}


	}
}
